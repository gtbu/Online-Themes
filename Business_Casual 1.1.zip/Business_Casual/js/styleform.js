$(document).ready(function(){
   
	
	
	//special form
		$("div.col-lg-12 .contactform ").wrap('<div class="row"></div>');
        $(".contactform label").slice(0,3).wrap('<div class="form-group col-lg-4"></div>');
		$(".contactform label:last, textarea#contact_message").wrapAll('<div class="form-group col-lg-12"></div>');
		$("input#contact_name").addClass('form-control');
		$("input#contact_email").addClass('form-control');
		$("input#contact_subject").addClass('form-control');
		$("textarea#contact_message").addClass('form-control');
		$("input.submit").wrap('<div class="form-group col-lg-12"></div>');
		$(".contactform .col-lg-12").first().before('<div class="clearfix"></div>');
		$("input.submit").addClass('btn btn-default');

//simple blog
	$(".comment_container .comment_area").after('<hr class="max">');
	$("input").not("#loginform input").addClass('form-control');
	$("textarea").addClass('form-control');
	$(".blog_nav_links a").addClass('btn btn-default');
	
	if ( $( ".single_blog_item" ).length == 0 ) {
					
					$(".blog_post .twysiwygr").after('<hr>');
					
					var a_number = [];
					$(".twysiwygr").each(function () {
						var all_a = $( "a" );
						a_number.push($(this).find(all_a).length);
					
					})
					var max_a = Math.max.apply(Math, a_number);	
					var min_a = Math.min.apply(Math, a_number);	
					
					if(min_a==0 || max_a > 1 ) {} else {
						$(".twysiwygr a:last-child").before('</br>');
						$(".twysiwygr a:last-child").addClass('btn btn-default readmore');
					}
					
									
				}
	if ( $( ".single_blog_item" ).length >0) {
					$("h2").after('<hr>');
					$("h2").before('<hr>');
					
				}
	
	
	console.log($( ".category_container" ).length);
	
	
	
});