<?php
global $page;
$path = $page->theme_dir.'/functions.php';
include_once($path);

?><!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		
		<!--[if lt IE 9]><?php
		// HTML5 shim, for IE6-8 support of HTML5 elements
		gpOutput::GetComponents( 'html5shiv' );
		gpOutput::GetComponents( 'respondjs' );
		?><![endif]-->

		 <!-- Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,700,600italic,800,700italic,800italic&subset=latin,cyrillic-ext,latin-ext,cyrillic' rel='stylesheet' type='text/css'>
		<link href="http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">

		<?php
		common::LoadComponents( 'bootstrap3-js' );
		gpOutput::GetHead();
		?>
		
		
	</head>


	<body>
	
<div class="top">
			<?php
			$GP_ARRANGE = false;
			gpOutput::Get('Extra','BC_Header');
			?>
</div>
	
		<div class="navbar navbar-default">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<?php
					global $config;
					echo common::Link('',$config['title'],'','class="navbar-brand"');
					?>
				</div>
				<div class="collapse navbar-collapse">
					<?php
					$GP_ARRANGE = false;
					$GP_MENU_CLASSES = array(
							'menu_top'			=> 'nav navbar-nav',
							'selected'			=> '',
							'selected_li'		=> 'active',
							'childselected'		=> '',
							'childselected_li'	=> '',
							'li_'				=> '',
							'li_title'			=> '',
							'haschildren'		=> 'dropdown-toggle',
							'haschildren_li'	=> 'dropdown',
							'child_ul'			=> 'dropdown-menu',
							);

					gpOutput::Get('TopTwoMenu'); 
					?>
				</div>
			</div>
		</div>



	
<div class="container">
   
   <?php if (is_front_page()) {?>	
         <div class="row">
            <div class="box">
                <div class="col-lg-12 text-center">
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="5000">
                        <!-- Indicators -->
						<?php if(count($slides)) {?>
						<ol class="carousel-indicators hidden-xs">
						<?php $active=true; $i=0;?>
						<?php foreach($slides as $slide) {?>
						<?php if($active){ ?>						
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i;?>" class="active"></li>
							<?php $active=false; $i++; ?>
						<?php } else { ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i;?>"></li>
                            <?php $i++; ?>
                       	<?php }  ?>
						<?php }  ?>
						 </ol>
						<?php } ?>
						<!-- Wrapper for slides -->
                       <?php if(count($slides)) {?>
					   <div class="carousel-inner">
                         <?php $active=true; $i=0;?>
						<?php foreach($slides as $slide) {?>
						  
							<?php if($active){ ?>	
							<div class="item active">
                               <?php $GP_ARRANGE = false; ?>
							   <?php gpOutput::Get('Extra',$slide); 
								$active=false; $i++; 
								?>
                            </div>
							<?php } else{ ?>
                            <div class="item">
								   <?php $GP_ARRANGE = false; ?>
                                  <?php gpOutput::Get('Extra',$slide); ?>
                            </div>
                         
						<?php } ?>							
						<?php } ?>
                        </div>
						<?php } ?>
						<!-- Controls -->
                        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                            <span class="icon-prev"></span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                            <span class="icon-next"></span>
                        </a>
                    </div>
                   
			<?php
			$GP_ARRANGE = false;
			gpOutput::Get('Extra','BC_Info');
			?>
	
					
                </div>
            </div>
        </div>
   
 <?php } ?>  
 
		 <div class="row">
            <div class="box">
                <div class="col-lg-12">
                   	<?php
					$page->GetContent();
						?>
				   
                </div>
            </div>
        </div>
		
		
</div> 
		
	
   <footer>
        <div class="container">
            <div class="row">
             <?php  if (is_front_page()) {?>
			 <div class="col-lg-6 text-center">
                    		<p><?php
				gpOutput::GetAdminLink();
					?></p>
					
                </div>
		
				<div class="col-lg-6 text-center">
 					<p>Copyright &copy; <?php echo $config['title']; ?> - <?php echo date('Y'); ?></p>
                </div>
			<?php } else { ?>	
				<div class="col-lg-12 text-center">
 					<p>Copyright &copy; <?php echo $config['title']; ?> - <?php echo date('Y'); ?></p>
                </div>
			<?php } ?>
			
            </div>
        </div>
    </footer>		
		
		
		

	</body>
</html>