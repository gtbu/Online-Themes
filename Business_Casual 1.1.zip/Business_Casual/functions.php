<?php


$GP_MENU_ELEMENTS = 'BootstrapMenu';

function BootstrapMenu($node, $attributes){
	GLOBAL $GP_MENU_LINKS;

	if( $node == 'a' ){
		$format = $GP_MENU_LINKS;
		$search = array('{$href_text}','{$attr}','{$label}','{$title}');

		if( in_array('dropdown-toggle',$attributes['class']) ){
			$format = '<a {$attr} data-toggle="dropdown" href="{$href_text}" title="{$title}">{$label}<b class="caret"></b></a>';
		}

		return str_replace( $search, $attributes, $format );
	}
}


function is_front_page(){
    		global $gp_menu, $page;
    		reset($gp_menu);
   			return $page->gp_index == key($gp_menu);
  }


global $dataDir, $dirPrefix;
if ($page->theme_is_addon) {
	$theme_path = '/data/_themes/' . $page->theme_name;
} else {
	$theme_path = '/themes/Business_Casual';
} 
$page->head_css[] = $theme_path . '/css/bootstrap.min.css';

if ($page->pagetype == "special_display"){
$page->head_js[] = $theme_path . '/js/styleform.js';
}


if (!file_exists($dataDir.'/data/_extra/Slide1.php')){
gpFiles::SaveFile($dataDir.'/data/_extra/Slide1.php','<p><img class="img-responsive img-full" alt="" src="'.$theme_path.'/img/slide-1.jpg" /></p>'); 
				}
if (!file_exists($dataDir.'/data/_extra/Slide2.php')){
gpFiles::SaveFile($dataDir.'/data/_extra/Slide2.php','<p><img class="img-responsive img-full" alt="" src="'.$theme_path.'/img/slide-2.jpg" /></p>'); 
				}
if (!file_exists($dataDir.'/data/_extra/Slide3.php')){
gpFiles::SaveFile($dataDir.'/data/_extra/Slide3.php','<p><img  class="img-responsive img-full" alt="" src="'.$theme_path.'/img/slide-3.jpg" /></p>'); 
				}
if (!file_exists($dataDir.'/data/_extra/Slide4.php')){
gpFiles::SaveFile($dataDir.'/data/_extra/Slide4.php','<div style="height: 393px; text-align: center;max-width: 100% !important;"><h2>Extra Content Slide4</h2>
<p>To add new slide simply create new extra content witn name Slide1, Slide2, Slide3...</p>
<p>Completely remove the contents of the slide , if you do not want to show it</p>
<p><a class="btn btn-lg btn-warning" href="/Admin_Extra">Got it!</a></p>
</div>'); 
				}				
if (!file_exists($dataDir.'/data/_extra/BC_Header.php')){
gpFiles::SaveFile($dataDir.'/data/_extra/BC_Header.php','<div class="brand">Business Casual</div><div class="address-bar">3481 Melrose Place | Beverly Hills, CA 90210 | 123.456.7890</div>'); 
				}				


$subjects = gpFiles::ReadDir($dataDir.'/data/_extra/',"php");
foreach ($subjects as $subject ){
if (preg_match('/^Slide/i', $subject, $matches)){
$slides_all[]=$subject;
}
}

foreach( $slides_all as $slide_one){
$line = file_get_contents($dataDir.'/data/_extra/'.$slide_one.'.php');
	if(!preg_match_all("/'content' => ''/", $line, $sovp)){
	 $slides[]=$slide_one;
	}

}






