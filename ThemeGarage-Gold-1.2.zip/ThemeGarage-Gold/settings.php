<?php

$GP_GETALLGADGETS = true;
$GP_STYLES = array();
$GP_STYLES[] = '#content';
