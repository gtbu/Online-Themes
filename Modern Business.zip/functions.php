<?PHP
  function MB_img_carousel($path) {
     $tab = array();
 
    $iterator = new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS);
 
    foreach(new RecursiveIteratorIterator($iterator) as $file) {
      if( preg_match('#\.(jpe?g|gif|png)$#i', $file))$tab[] = $file->getfilename();
    }
    return $tab;
  }
  