<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php 
     include 'settings.php';
     include 'functions.php';
     gpOutput::GetHead();  
     $page->head_js[] = common::GetDir().'include/thirdparty/Bootstrap3/js/bootstrap.min.js';
     $page->head_js[] = dirname($page->theme_path) . '/js/template.js';
    ?> 
    <title></title>
    <!--[if lt IE 9]><?php
	  // HTML5 shim, for IE6-8 support of HTML5 elements
	  gpOutput::GetComponents( 'html5shiv' );
	  gpOutput::GetComponents( 'respondjs' );
	  ?><![endif]-->
    
</head>

<body>
    
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top gp-fixed-adjust" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button id="bt_id" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-co">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php echo common::Link('',$config['title'],'','class="navbar-brand"'); ?>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="navbar-co">
            	
              <?php gpOutput::Get('FullMenu'); ?> 
             
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<?php 
  if($MB_Carousel){ 
  	$tab_img = array();
  	$tab_img = MB_img_carousel($MB_Carousel_Path);
  	$nb_tab  = count($tab_img);
  	?>
    <!-- Header Carousel -->
    <header id="myCarousel" class="carousel slide">
    	<?php 
    	 if($MB_Carousel_Indicators){?>
        <!-- Indicators -->
        <ol class="carousel-indicators">
        	<?php 
        	  for($i=0; $i < $nb_tab;$i++){
        	  	if($i==0)
                echo '<li data-target="#myCarousel" data-slide-to="'.$i.'" class="active"></li>';
              else
                echo '<li data-target="#myCarousel" data-slide-to="'.$i.'"></li>';
            }
          ?>
        </ol>
       <?php }?>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
        	<?php 
        	  $html='';
        	  for($i=0; $i < $nb_tab;$i++){
        	  	if($i == 0) $class_active = 'active';
        	  	else $class_active = '';
        	  	$caption = explode('-',$tab_img[$i]);
              $html .= '<div class="item '.$class_active.'">
                         <div class="fill" style="background-image:url(\''. dirname($page->theme_path).'/images/carousel/'.$tab_img[$i].'\');"></div>';
                         
              if($MB_Carousel_caption)
                 $html .= '<div class="carousel-caption">
                             <h2>'.$caption[0].'</h2>
                           </div>';
              $html .= '</div>';
            }
            echo $html;
          ?>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>
<?php }?>
    <!-- Page Content -->
    <div class="container">
       <?php $page->GetContent(); ?>

        <!-- Footer -->
        <footer>
            <div class="foot"><?php	gpOutput::GetAdminLink();	?></div>
        </footer>

    </div>
    <!-- /.container -->

</body>

</html>
