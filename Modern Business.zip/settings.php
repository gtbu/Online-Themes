<?php

global $config,$page,$addonRelativeCode,$addonPathCode;
$MB_Carousel = true;
$MB_Carousel_caption = true;
$MB_Carousel_Indicators = true;
$MB_Carousel_Path = __DIR__.'/images/carousel/';

