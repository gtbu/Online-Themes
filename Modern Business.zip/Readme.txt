In setting.php file there are 3 variables for the carousel:
$ MB_Carousel: (true) Displays the carousel (false) or not
$ MB_Carousel_caption: Displays text for images or not
$ MB_Carousel_Indicators: Displays the indicators under the caption or not

To use the carousel, just copy the pictures to display in the folder images/carousel.
To display the name of the images in the carousel, simply forward it by a high-dash.
Example: My Picture-exemple1.jpg show caption "My Picture"
Take a look in images/carousel to see the sample pictures