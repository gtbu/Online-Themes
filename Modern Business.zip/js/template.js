function responsiveFn() { 
    men = $('.gpArea_FullMenu ul').first();
    if ($('#bt_id').is(":visible")){
    	 $('.menu_top li').css({'float': 'none'});
    	 men.removeClass('menu_top');
    	}
	  else {
	  	$('.menu_top li').css({'float': 'left'});
    	 men.addClass('menu_top');
	  }
 }

  // load() event and resize() event are combined 
   $(window).ready(responsiveFn).resize(responsiveFn);
