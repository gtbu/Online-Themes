<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 3.0 License

Name       : Big Business
Description: A two-column, fixed-width design with a bright color scheme.
Version    : 1.0
Released   : 20120210
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<?php gpOutput::GetHead(); ?>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo">
		<?php global $dataDir;
					if (!file_exists($dataDir.'\data\_extra\Headd.php')){
						gpFiles::SaveFile($dataDir.'\data\_extra\Headd.php','<h1><a href="/" title="My gpEasy CMS">My gpEasy CMS</a></h1>');
					}
					gpOutput::Get('Extra','Headd');
				?>
		</div>
		<div id="slogan">
						<?php global $dataDir;
					if (!file_exists($dataDir.'\data\_extra\Slogann.php')){
						gpFiles::SaveFile($dataDir.'\data\_extra\Slogann.php','<h2>Template design by Free CSS Templates</h2>');
					}
					gpOutput::Get('Extra','Slogann');
				?>
			
		</div>
	</div>
	<div id="menu">
			<?php
			$GP_ARRANGE = false;
			gpOutput::Get('Menu');
			?>
		<br class="clearfix" />
	</div>
	<div id="splash">
		<img class="pic" src="/themes/Bigbusiness/Main/images/pic01.jpg" width="870" height="230" alt="" />
	</div>
	<div id="page">
		<div id="content">
			<div class="box">
				<?php
			$page->GetContent();
			?>
			</div>
		</div>
		<div id="sidebar">
			<div class="box">
							<?php
			gpOutput::Get('Extra','Side_Menu');
			?>
			</div>
			<div class="box">
				<?php gpOutput::GetAllGadgets(); ?>
				</div>
			</div>
		</div>
		<br class="clearfix" />
	</div>
	<div id="page-bottom">
		<div id="page-bottom-content">
					<?php global $dataDir;
					if (!file_exists($dataDir.'\data\_extra\Foot.php')){
						gpFiles::SaveFile($dataDir.'\data\_extra\Foot.php','<h3>Magnis hendrerit erat</h3><p>Euismod sodales sociis hendrerit pulvinar molestie urna. Consectetur egestas sodales at ornare laoreet turpis. Lorem id sapien ridiculus sagittis imperdiet urna suspendisse. Posuere arcu parturient quam risus. Aliquam nullam magnis integer gravida vulputate felis. Consectetur montes sollicitudin dictum. Auctor sociis hendrerit pulvinar molestie urna lorem ipsum dolor vivamus pulvinar libero. Massa egestas cubilia lacus augue mattis consectetur.</p>');
					}
					gpOutput::Get('Extra','Foot');
				?>
		</div>

		<br class="clearfix" />
	</div>
</div>
<div id="footer">
	<?php
		gpOutput::GetAdminLink();
		?> Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.
</div>
</body>
</html>