<?php

/*
Template Name:	Bigbusiness
Version:		1.1
min-gp|Easy:	2.xx
Created:        Feb 2012
---------------------------------------------------------  */

$GP_STYLES = array();
$GP_STYLES[] = '#header';
$GP_STYLES[] = '#menu';
$GP_STYLES[] = '#content';
$GP_STYLES[] = '#sidebar';
$GP_STYLES[] = '#footer';

$link = common::Link('','%s');
gpOutput::Area('Headd','<h1>'.$link.'</h1>');
