<?php gpOutput::Area('Header_spe','<div class="Header_spe">%s</div>'); ?>
<!DOCTYPE html>
<html lang="fr">
  <head>
   <meta charset="utf-8" />
    <?php 
     global $config;
     common::AddColorBox();
     gpOutput::GetHead();  
     $page->head .= '<script type="text/javascript" src="'.common::GetDir().'themes/Business/template.js"></script>';
    ?> 
    <title></title>
  </head>
<body>
<div id="warp">
    <div class="header">
      <div class="head-top">
        <?php gpOutput::GetGadget('Language_Select');?>
      </div>
      <div class="head-bottom">
        <div class="logo">
             <h1><span class="text_logo"><?php echo $config['title'] ?></span> </h1>
        </div>
        <div class="logo_right">
          <div><?php gpOutput::GetArea('Header_spe','gpEasy... when Performance Matters! Put here your Business Slogans'); ?> </div>
          <div id="menuwrap">
             <?php gpOutput::Get('FullMenu'); ?> 
          </div>
        </div>
        <div style="clear:both"></div>
      </div>
    </div>
    <div class="banner">
      <div class="banner-pic"></div>
      <div class="banner-text">
           <?php gpOutput::Get('Extra','Header');?>
      </div>
    </div>      
    <div class="content">
      <div class="main_content"><?php	$page->GetContent(); ?></div>
      <div id="sidebar"> <?php gpOutput::Get('Extra','Side_Menu'); gpOutput::GetAllGadgets(); ?></div>    
      <div class="clear"></div>
    </div>
    <div class="foot"><?php	gpOutput::GetAdminLink();	?></div>
</div>
</body>
</html>
