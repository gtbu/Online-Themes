
$(window).load(function(){
	//delete 'Language_Select' from all gadgets load on sidebar
	if($('div#sidebar div.gpArea_Language_Select').length>0)$('div#sidebar div.gpArea_Language_Select').remove();
	//delete texte 'language'
	if($('div.head-top div.multi_lang_select').length>0)$('div.multi_lang_select div b').remove();	
});