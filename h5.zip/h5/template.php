<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<?php gpOutput::GetHead(); ?>
	<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<link rel="shortcut icon" href="themes/h5/favicon.ico" />
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
	
	<header class="wrap">
		<?php
		global $config;
		$default_value = $config['title'];
		$GP_ARRANGE = false;
		gpOutput::GetArea('header',$default_value);
		?>
	</header>
	<nav class="wrap">	
		<?php 
		$GP_ARRANGE = false;
		gpOutput::Get('TopTwoMenu');
		?>
	</nav>

	<div id="page" class="wrap cf">
		<div id="content">
			<?php $page->GetContent(); ?>
		</div>

		<aside>
			<?php 
			gpOutput::Get('Extra','Side_Menu');
			gpOutput::GetAllGadgets();  
			?>
		</aside>
	</div>
	<div class="footer">
		<footer class="wrap cf">
			<section class="footarea">
				<?php gpOutput::Get('Extra','Footer'); ?>
			</section>
			<section class="footarea">
				<?php gpOutput::Get('Extra','Footer 2'); ?>
			</section>
			<section class="footarea">
				<?php gpOutput::Get('Extra','Footer 3'); ?>
			</section>
			<p class="footerlinks"><?php gpOutput::GetAdminLink(); ?></p>
		</footer>
	</div>

</body>
</html>
