<?php

$GP_STYLES = array();
$GP_STYLES[] = '#content';
$GP_STYLES[] = '#footer';
$GP_STYLES[] = '#sidepanel';

$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<?php gpOutput::GetHead(); ?>
				
</head>
<body>

	<div id="wrapper">

	<div id="header">
		<div id="menu">
			<?php 
			$GP_ARRANGE = false;
			gpOutput::Get('TopTwoMenu');
			?>
			<div class="clear"></div>
		</div>
		<div id="header_h1">
		<?php
		gpOutput::GetArea('header','gp|Easy CMS');

		?>
		</div>
	</div>
	

	<div id="bodywrapper">
		<div id="sidepanel">
			<div id="fullmenu">
				<?php gpOutput::Get('FullMenu'); ?>
			</div>
			<?php 
			gpOutput::Get('Extra','Side_Menu'); 
			?>
			<?php gpOutput::GetAllGadgets(); ?>
		</div>
		<div id="content">
			<?php 
			$page->GetContent(); 
			?>
		</div>
					
		<div style="clear:both"></div>
	</div>

	<div id="footer">
		<?php
		gpOutput::Get('Extra','Footer');
		echo '<div>';
		gpOutput::GetAdminLink();
		echo '</div>';
		?>
	</div>
	
</div>

</body>
</html>
