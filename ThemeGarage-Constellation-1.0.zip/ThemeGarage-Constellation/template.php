<?php

global $page;

$GP_MENU_ELEMENTS = 'BootstrapMenu';
$URL = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';

function BootstrapMenu($node, $attributes){
	GLOBAL $GP_MENU_LINKS;

	if( $node == 'a' ){
		$format = $GP_MENU_LINKS;
		$search = array('{$href_text}','{$attr}','{$label}','{$title}');

		if( in_array('dropdown-toggle',$attributes['class']) ){
			$format = '<a {$attr} data-toggle="dropdown" href="{$href_text}" title="{$title}">{$label}<b class="caret"></b></a>';
		}

		return str_replace( $search, $attributes, $format );
	}
}
function ob_html_compress($buf){
    return str_replace(array("\n","\r","\t"),'',$buf);
}

ob_start("ob_html_compress");

?>
<!doctype html>
<!--[if IE 6 ]><html lang="de-DE" class="ie6"> <![endif]--> 
<!--[if IE 7 ]><html lang="de-DE" class="ie7"> <![endif]--> 
<!--[if IE 8 ]><html lang="de-DE" class="ie8"> <![endif]--> 
<!--[if (gt IE 7)|!(IE)]><!--> 
<html lang="de" class="no-js">
<!--<![endif]-->  
<head>
	<meta charset="UTF-8" />
	<meta name="revisit-after" content="15 days" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="apple-mobile-web-app-status-bar-style" content="15 days" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<meta name="theme-color" content="#333" />
	<meta name="googlebot" content="noodp" />
	<meta name="robots" content="all">
    <meta name="author" content="ThemeGarage">
	<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<link rel="shortcut icon" href="<?php echo dirname($page->theme_path); ?>/favicon.ico" />
	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="<?php echo dirname($page->theme_path); ?>/Normal/apple-touch-icon-57x57.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo dirname($page->theme_path); ?>/Normal/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo dirname($page->theme_path); ?>/Normal/apple-touch-icon-114x114.png">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge" /><![endif]-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<?php gpOutput::GetHead(); ?>
	<link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body data-spy="scroll" data-offset="80" class="hide-<?php echo $page->meta_data['file_number']; ?>">
	<div class="wrap" style="background-image: url(<?php echo dirname($page->theme_path) . '/Normal/wrap.jpg'; ?>)">
		<!-- PRELOADER -->
		<div class="preloader">
			<div class="status">
				<div class="status-mes"></div>
			</div>
		</div>
		<!-- PRELOADER -->

		<!-- START TOPMENU -->
    	<div class="container-fluid topmenu">
        	<div class="container">
              <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<?php
					$GP_ARRANGE = false;
					$GP_MENU_CLASSES = array(
							'menu_top'			=> 'nav navbar-nav',
							'selected'			=> '',
							'selected_li'		=> 'active',
							'childselected'		=> '',
							'childselected_li'	=> 'active',
							'li_'				=> '',
							'li_title'			=> '',
							'haschildren'		=> 'dropdown-toggle',
							'haschildren_li'	=> 'dropdown',
							'child_ul'			=> 'dropdown-menu',
							);
					gpOutput::Get('TopTwoMenu'); //top two levels
				?>
                </div>
              </div><!--row end-->
            </div>
        </div><!--topmenu end-->
		<!-- END TOPMENU -->
        
		<!-- START NAVBAR -->
        <div class="container-fluid headtop">
        	<nav class="navbar navbar-default menu_dropdown">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
				<a class="logo" href="<?php echo $URL; ?>"><?php gpOutput::GetImage('/Normal/themegarage.png'); ?></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar">
				<?php
					$GP_ARRANGE = false;
					$GP_MENU_CLASSES = array(
							'menu_top'			=> 'nav navbar-nav',
							'selected'			=> '',
							'selected_li'		=> 'active',
							'childselected'		=> '',
							'childselected_li'	=> 'active',
							'li_'				=> '',
							'li_title'			=> '',
							'haschildren'		=> 'dropdown-toggle',
							'haschildren_li'	=> 'dropdown',
							'child_ul'			=> 'dropdown-menu',
							);
					gpOutput::Get('TopTwoMenu'); //top two levels
				?>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>
        </div>
		<!-- END NAVBAR -->

		<!-- START HOME -->
    	<div class="container-fluid top" style="background-image: url(<?php echo dirname($page->theme_path) . '/Normal/pixelBlack.png'; ?>)">
		<canvas style="position:absolute;"></canvas>
		<div class="row">
                <div class="header">
                	<div class="container text-centered overlay">
						<div class="header_info">
						<?php gpOutput::Get('Extra','START_SECTION'); ?>
						</div>
                    </div>
                </div>
              </div><!--row end-->
        </div><!--top end-->
        <!-- END HOME -->

		<!-- START ABOUT-->
		<section id="about" class="about-promotion section-padding">
			<div class="container">
				<div class="row">
					<div class="section-title wow zoomIn">
                        <?php $page->GetContent(); ?>
					</div>			
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</section>
		<!-- END ABOUT -->

		<!-- START ABOUT-2-->
		<section id="about-2" class="about-promotion section-padding" style="background-image: url(<?php echo dirname($page->theme_path) . '/Normal/about-2.jpg'; ?>)">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-sm-12 col-xs-12">
						<div class="about-slide">
							<div id="about-carousel" class="carousel slide carousel-fade" data-ride="carousel">
								<div class="carousel-inner" role="listbox">
									<div class="item active">
                                    	<?php gpOutput::GetImage('/Normal/1.jpg', array('width'=>'100%','height'=>'auto')); ?>
									</div>
									<div class="item">
										<?php gpOutput::GetImage('/Normal/2.jpg', array('width'=>'100%','height'=>'auto')); ?>
									</div>
									<div class="item">
										<?php gpOutput::GetImage('/Normal/3.jpg', array('width'=>'100%','height'=>'auto')); ?>
									</div>
								</div>
								<a class="left slide-control" href="#about-carousel" role="button" data-slide="prev">
									<i class="fa  fa-angle-left"></i>
								</a>
								<a class="right slide-control" href="#about-carousel" role="button" data-slide="next">
									<i class="fa fa-angle-right"></i>
								</a>
							</div>
						</div>
					</div><!-- END COL  -->						
					<div class="col-md-5 col-sm-12 col-xs-12">
						<div class="intro-section">
							<?php gpOutput::Get('Extra','INTRO_SECTION'); ?>
						</div>
					</div><!-- END COL  -->				
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</section>
		<!-- END ABOUT-2 -->

		<!-- START COMPANY PARTNER LOGO  -->
		<div class="partner-logo section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="partner wow fadeInRight">
							<a href="#"><?php gpOutput::GetImage('/Normal/l1.png', array('width'=>'auto','height'=>'auto')); ?></a>
							<a href="#"><?php gpOutput::GetImage('/Normal/l2.png', array('width'=>'auto','height'=>'auto')); ?></a>
                            <a href="#"><?php gpOutput::GetImage('/Normal/l3.png', array('width'=>'auto','height'=>'auto')); ?></a>
                            <a href="#"><?php gpOutput::GetImage('/Normal/l4.png', array('width'=>'auto','height'=>'auto')); ?></a>
                            <a href="#"><?php gpOutput::GetImage('/Normal/l5.png', array('width'=>'auto','height'=>'auto')); ?></a>
                            <a href="#"><?php gpOutput::GetImage('/Normal/l6.png', array('width'=>'auto','height'=>'auto')); ?></a>
						</div>
					</div><!-- END COL  -->
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</div>
		<!-- END COMPANY PARTNER LOGO -->

		<!-- START FOOTER -->
		<footer id="contact" class="footer">
			<div class="container">
				<div class="row section-padding">	
					<div class="col-md-4 col-sm-4 col-xs-12 wow bounceIn page-scroll" data-wow-delay=".2s">
						<div class="single_footer">
							<?php gpOutput::Get('Extra','FOOTER_1_SECTION'); ?>
						</div>	
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-4 col-xs-12 wow bounceIn page-scroll" data-wow-delay=".3s">
						<div class="single_footer">
							<?php gpOutput::Get('Extra','FOOTER_2_SECTION'); ?>
						</div>	
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-4 col-xs-12 wow bounceIn page-scroll" data-wow-delay=".4s">
						<div class="single_footer">
							<?php gpOutput::Get('Extra','FOOTER_3_SECTION'); ?>
						</div>	
					</div><!--- END COL -->					
				</div><!--- END ROW -->	
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="copyright">
							<?php gpOutput::Get('Extra','COPYRIGHT_SECTION'); ?>
						</div><!--- END FOOTER COPYRIGHT -->
					</div><!--- END COL -->					
				</div>
				<div class="text-centered"><?php gpOutput::GetAdminLink(); ?></div>
			</div><!--- END CONTAINER -->
		</footer>
		<!-- END FOOTER -->	

	<?php
		$page->head_js[] = dirname($page->theme_path) . '/Normal/bootstrap.min.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/ie10-viewport-bug-workaround.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/parallax.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/modernizr-2.8.3.min.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/scrolltopcontrol.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/wow.min.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/owl.carousel.min.js';
		$page->head_js[] = dirname($page->theme_path) . '/Normal/scripts.js';
	?>
	</div>
</body>
</html>

<?php ob_end_flush(); ?>
